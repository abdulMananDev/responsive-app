
True Type Font: Sans Serif Plus 7 version 3.0


EULA
-==-
The font Sans Serif Plus 7 is freeware for home use only.


DESCRIPTION
-=========-
Original light sans serif font. Supported code pages: 1250 "Central European", 1251 "Cyrillic", 1252 "Latin 1".

Files in sans_serif_plus_7.zip:
       	readme.txt     			this file;
        sans_serif_plus_7.ttf 		regular font;
	sans_serif_plus_7_screen.png	preview image.

Please visit http://www.styleseven.com/ to download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


EXAMPLE OF FONT USAGE
-==================-
See also example of the font usage: https://play.google.com/store/apps/details?id=com.style7.modernclockforandroid_7


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software without any charge (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.

Use this link to buy the license ($24.95): http://store.esellerate.net/s.aspx?s=STR0331655240
Please enter font name in web form.


WHAT'S NEW?
-=========-
* Version 1.01 {June 15 2015}.
 - Digits are changed.
* Version 2.0 {July 6 2015}.
 - All symbols for "Latin 1" code page is added;
 - Cyrillic code page is added.
* Version 3.0 {March 4 2018}.
 - All symbols for 1250 "Central European" code page is added;


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: April 4 2015